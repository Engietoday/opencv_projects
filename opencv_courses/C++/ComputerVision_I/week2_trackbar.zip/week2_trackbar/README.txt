run build_and_run.sh to build and run the program. Make sure terminal is cd into week2_trackbar folder. 
