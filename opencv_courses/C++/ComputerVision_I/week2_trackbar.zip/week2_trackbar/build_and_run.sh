# Make sure to run this build script in "week2_trackbar" folder.

mkdir build
cd build
cmake ..
make
./main
